if __name__ == "__main__":
    from nb2minimod.cli import app
    app()